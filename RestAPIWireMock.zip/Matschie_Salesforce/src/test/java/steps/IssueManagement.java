package steps;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;

import java.net.URI;
import java.util.Map;
import java.util.Map.Entry;
import io.cucumber.java.en.*;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;

import org.apache.commons.lang3.StringUtils;

public class IssueManagement extends baseAPI{
	
	public String id;

	@Given("enable logs")
	public void setUp(){ 
		request = given().log().all();
	}
	
	@And("lead is created with (.*) and (.*) and (.*)$")
	public void add_mandatoryDetails(String last_name,String first_name,String company_name){
		request = request.when().body("{\r\n"
				+ "    	\"FirstName\": \""+first_name+"\",\r\n"
				+ "    	\"LastName\": \""+last_name+"\",\r\n"
				+ "    	\"Company\": \""+company_name+"\"  \r\n"
				+ "	}");
	}
	
	@And("lead is created")
	public void create_lead() {
		response = request.when().contentType(ContentType.JSON).post("lead");
		JsonPath jsonPath = response.jsonPath();
		id = jsonPath.get("id");
		System.out.println(id);
		//response.prettyPrint();
	}
	@When("new issue is created in table")
	public void a_new_incident_created(){
		response = request.when().contentType(ContentType.JSON).post("lead");
		response.prettyPrint();
	}
	
	@When("request is sent to delete a lead in table")
	public void delete_lead(){
		response = request.when().contentType(ContentType.JSON).delete("lead/"+id);
		response.prettyPrint();
	}
	
	@When("request is sent to view created leads")
	public void view_leads(){
		response = request.when().contentType(ContentType.JSON).get();
	
		response.prettyPrint();
	}
	
//	@When("get all incidents")
//	public void get_all_incidents(){
//		response = request.when().contentType(ContentType.JSON).get("incident");
//		response.prettyPrint();
//	}

	@Then("the status code is (\\d+)$")// \d+ ->only Digit += 1 or more number
	public void verify_status_code(int statusCode){
		json = response.then().statusCode(statusCode);
	}

	@And("response includes the following$")
	public void response_equals(Map<String,String> responseFields){
		
		for (Entry<String, String> eachEntry : responseFields.entrySet()) {
			
			if(StringUtils.isNumeric(eachEntry.getValue())) {
				response
				.then()
				.body(eachEntry.getKey(), equalTo(Integer.parseInt(eachEntry.getValue())));
			} else {
				response
				.then()
				.body(eachEntry.getKey(), equalTo(eachEntry.getValue()));
			}
		}
	}	
	
	
	@And("response includes the following in any order$")
	public void response_contains_in_any_order(Map<String,String> responseFields){
		for (Map.Entry<String, String> field : responseFields.entrySet()) {
			if(StringUtils.isNumeric(field.getValue())){// checking
				json.body(field.getKey(), containsInAnyOrder(Integer.parseInt(field.getValue())));
			}
			else{
				json.body(field.getKey(), containsInAnyOrder(field.getValue()));
			}
		}
	}
}


