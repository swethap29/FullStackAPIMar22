package steps;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;

import java.net.URI;
import java.util.Map;
import java.util.Map.Entry;
import io.cucumber.java.en.*;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;

import org.apache.commons.lang3.StringUtils;

public class IssueManagement extends baseAPI{
	
	public String id;

	@Given("enable logs")
	public void setUp(){ 
		request = given().log().all();
	}
	
	@And("CR is created with category as (.*) and short description as (.*)$")
	public void add_mandatoryDetails(String category,String short_desc){
		request = request.when().body("{\r\n"
				+ "    \"category\": \""+category+"\",\r\n"
				+ "    \"short_description\": \""+short_desc+"\"\r\n"
				+ "}");
	}
	
	@And("lead is created")
	public void create_lead() {
		response = request.when().contentType(ContentType.JSON).post("lead");
		JsonPath jsonPath = response.jsonPath();
		id = jsonPath.get("result.sys_id");
		System.out.println(id);
		//response.prettyPrint();
	}
	@When("new CR is created in table")
	public void a_new_incident_created(){
		response = request.when().contentType(ContentType.JSON).post();
		response.prettyPrint();
	}
	@And("new CR created in table")
	public void a_new_incident_created_toapassID(){
		response = request.when().contentType(ContentType.JSON).body("{\r\n"
				+ "    \"category\": \"Software\",\r\n"
				+ "    \"short_description\": \"Windows update\"\r\n"
				+ "}").post();
		JsonPath jsonPath = response.jsonPath();
		id = jsonPath.get("result.sys_id");
		System.out.println(id);
		response.prettyPrint();
	}
	@When("request is sent to update CR")
	public void update_CR(){
		response = request.when().contentType(ContentType.JSON).body("{\r\n"
				+ "    \"category\": \"Inquiry\",\r\n"
				+ "    \"priority\": 2\r\n"
				+ "}").put("/"+id);
		response.prettyPrint();
	}
	@When("request is sent to delete CR")
	public void delete_leads(){
		
	
		response = request.when().delete("/"+id);
	
		response.prettyPrint();
	}
	
	@When("request is sent to view created leads")
	public void view_leads(){
		response = request.when().contentType(ContentType.JSON).get();
	
		response.prettyPrint();
	}
	
//	@When("get all incidents")
//	public void get_all_incidents(){
//		response = request.when().contentType(ContentType.JSON).get("incident");
//		response.prettyPrint();
//	}

	@Then("the status code is (\\d+)$")// \d+ ->only Digit += 1 or more number
	public void verify_status_code(int statusCode){
		json = response.then().statusCode(statusCode);
	}

	@And("response includes the following$")
	public void response_equals(Map<String,String> responseFields){
		
		for (Entry<String, String> eachEntry : responseFields.entrySet()) {
			
			if(StringUtils.isNumeric(eachEntry.getValue())) {
				response
				.then()
				.body(eachEntry.getKey(), equalTo(Integer.parseInt(eachEntry.getValue())));
			} else {
				response
				.then()
				.body(eachEntry.getKey(), equalTo(eachEntry.getValue()));
			}
		}
	}	
	
	
	@And("response includes the following in any order$")
	public void response_contains_in_any_order(Map<String,String> responseFields){
		for (Map.Entry<String, String> field : responseFields.entrySet()) {
			if(StringUtils.isNumeric(field.getValue())){// checking
				json.body(field.getKey(), containsInAnyOrder(Integer.parseInt(field.getValue())));
			}
			else{
				json.body(field.getKey(), containsInAnyOrder(field.getValue()));
			}
		}
	}
}


